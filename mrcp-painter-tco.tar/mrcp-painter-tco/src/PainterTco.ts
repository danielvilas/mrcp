import { Layout } from 'mrcp-layout-model'
import * as fs from 'fs'
import * as path from 'path';
import { fabric} from 'fabric';
import { IRectOptions } from 'fabric/fabric-impl';

type Size={width: number; height: number;}


export type PainterTcoOptions = {
    name:string
    format?: 'svg'|'png'
    size?:Size
    outFile?:string
    grid?:boolean
    markStart?:boolean,
    gridBase?:number
}

export const PainterTcoDefaultOptions:PainterTcoOptions={
    name:undefined,
    format: 'svg',
    size:{height:100,width:100},
    outFile:"out.svg",
    grid:false,
    markStart:false,
    gridBase:5,
}


const panelLayersKind=['grid','track','cut','led','outs']
export type PanelLayersKind='grid'|'track'|'cut'|'led'|'outs'
export type PanelLayers={[key in PanelLayersKind]?:fabric.Group}

export class PainterTco {

    public constructor(_options:PainterTcoOptions) {
        this.options={...PainterTcoDefaultOptions, ..._options}
    }

    private options:PainterTcoOptions
    private svg:string

    private layers:PanelLayers

    public paint(layout:Layout): void {
        const canvas = new fabric.StaticCanvas(null, { });
        //const rect = new fabric.Rect({ width: 20, height: 50, fill: '#ff0000' });
        const text = new fabric.Text('fabric.js', { fill: 'blue', fontSize: 24 });
        this.layers={}

        panelLayersKind.map((value)=>{
            let grp = new fabric.Group(null,{})
            grp["id"]=value
            this.layers[value]=grp
            canvas.add(grp)
        })
        this.layers.track.add(text);
        if(this.grid){
            this.paintGrid();
        }



        canvas.renderAll();
        let opts:fabric.IToSVGOptions={height:this.options.size.height,
             width:this.options.size.width,
             viewBox:{x:0,y:0,
                width:this.options.size.width,
                height:this.options.size.height}}
        // Modify the width and heign to have some strings
        let t = "height"; opts[t]=(this.options.size.height/10)+"cm"; t = "width"; opts[t]=(this.options.size.width/10)+"cm"
        //
        this.svg=canvas.toSVG(opts);
    }

    private paintGrid():void {
        let layer=this.layers.grid
        layer.add(new fabric.Rect({...rectPostion(0,0,this.options.size.height,this.options.size.width),
            fill:"white"}))

        // Paint the grid lines by hand, because fabric.js doesn't allow to create a svg pattern()
        let y =0;
        let line=0;
        while (y<=this.options.size.height){
            if(line%4==0){
                //Big line
                layer.add(new fabric.Line([0,y,this.options.size.width,y],{stroke:"#0000C8", strokeWidth:0.2}));
            } else {
                layer.add(new fabric.Line([0,y,this.options.size.width,y],{stroke:"#0000C8", strokeWidth:0.1}));
            }
            
            y+=this.options.gridBase;
            line++;
        }
        let x =0;
        line=0;
        while (x<=this.options.size.width){
            if(line%4==0){
                //Big line
                layer.add(new fabric.Line([x,0,x,this.options.size.height],{stroke:"#0000C8", strokeWidth:0.2}));
            } else {
                layer.add(new fabric.Line([x,0,x,this.options.size.height],{stroke:"#0000C8", strokeWidth:0.1}));
            }
            
            x+=this.options.gridBase;
            line++;
        }
        //layer.add(self._dwg.rect(size=size, fill=patternBig.get_paint_server()))

    }

    public grid(grid=true){
        this.options.grid=grid;
    }
    public markStart(markStart=true){
        this.options.markStart=markStart;
    }

    public save():void{
        console.log(this.svg);
        fs.writeFile(path.resolve(this.options.outFile), this.svg.toString(), function (err) {
            if (err) throw err;
            console.log('Saved!');
        });
    }
}

export function rectPostion(x:number,y:number,height:number,width:number):IRectOptions{
    return{
        width:width,
        height:height,
        originX:'center',
        originY:'center',
        left:x+width/2,
        top:y+height/2,
    }
}